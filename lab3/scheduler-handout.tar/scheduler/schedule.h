#ifndef _schedule_h_
#define _schedule_h_


int addProcess(int tid);
int removeProcess(int tid);
int nextProcess();

#endif
