/** Automatically generated file. DO NOT MODIFY */
package csci567.simpleui;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}