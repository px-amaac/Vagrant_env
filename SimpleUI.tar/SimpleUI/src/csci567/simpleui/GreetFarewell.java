package csci567.simpleui;

public class GreetFarewell {
	private int 	mGreeting;
	private int 	mFarewell;
	private String	mLanguage;
	private boolean	mType; // 1 = greeting, 0 = farewell
	
	public GreetFarewell(int greeting, int farewell, String language) {
		mGreeting = greeting;
		mFarewell = farewell;
		mLanguage = language;
	}

	public int getGreeting() {
		return mGreeting;
	}

	public void setGreeting(int greeting) {
		mGreeting = greeting;
	}

	public int getFarewell() {
		return mFarewell;
	}

	public void setFarewell(int farewell) {
		mFarewell = farewell;
	}

	public String getLanguage() {
		return mLanguage;
	}

	public void setLanguage(String language) {
		mLanguage = language;
	}	
	
}
