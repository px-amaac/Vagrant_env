package csci567.simpleui;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	
	private Button mGreetingBtn;
	private Button mFarewellBtn;
	private TextView mGreetingTextView;
	
	private GreetFarewell[] mGreetingBank = new GreetFarewell[] {
			new GreetFarewell(R.string.english_hello, R.string.english_goodbye, "English"),
			new GreetFarewell(R.string.spanish_hello, R.string.spanish_goodbye, "Spanish"),
			new GreetFarewell(R.string.french_hello, R.string.french_goodbye, "French"),
			new GreetFarewell(R.string.german_hello, R.string.german_goodbye, "German"),
			new GreetFarewell(R.string.italian_hello, R.string.italian_goodbye, "Italian"),
			new GreetFarewell(R.string.chinese_hello, R.string.chinese_goodbye, "Chinese"),
			new GreetFarewell(R.string.russian_hello, R.string.russian_goodbye, "Russian"),
			new GreetFarewell(R.string.japanese_hello, R.string.japanese_goodbye, "Japanese"),
			new GreetFarewell(R.string.welsh_hello, R.string.welsh_goodbye, "Welsh"),
			new GreetFarewell(R.string.hmong_hello, R.string.hmong_goodbye, "Hmong"),
			new GreetFarewell(R.string.korean_hello, R.string.korean_goodbye, "Korean"),
			new GreetFarewell(R.string.portuguese_hello, R.string.portuguese_goodbye, "Portuguese")
	};
	
	private int mIndex = 0;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		mGreetingBtn = (Button) this.findViewById(R.id.greeting_btn);
		mFarewellBtn = (Button) this.findViewById(R.id.farewell_btn);
		mGreetingTextView = (TextView) this.findViewById(R.id.greeting_text);
		
		
		mGreetingBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				mIndex = (int) (Math.random() * mGreetingBank.length);
				Log.d("Random", "mIndex = " + mIndex);
				mGreetingTextView.setText(mGreetingBank[mIndex].getGreeting());
				Toast.makeText(MainActivity.this, mGreetingBank[mIndex].getLanguage(), Toast.LENGTH_LONG).show();
				
			}
		});
		
		mFarewellBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				mIndex = (int) (Math.random() * mGreetingBank.length);
				mGreetingTextView.setText(mGreetingBank[mIndex].getFarewell());
				Toast.makeText(MainActivity.this, mGreetingBank[mIndex].getLanguage(), Toast.LENGTH_LONG).show();
				
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
